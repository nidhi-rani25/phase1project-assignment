package phase1project;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
public class javaproject
{
	   public void maincontent() {
		int choice='\0';
		Scanner sc=new Scanner(System.in);
		// Welcome message
		System.out.println("JAVA LOCKERSAPP");
		System.out.println("Welcome to LockedMe.com");
		System.out.println("Developer - NIDHI RANI");
		System.out.println("COMPANY:- SIMPLILEARN");
		do
		{
			System.out.println("\n1. Retrieving current files names in ascending order");
			System.out.println("2. Bussiness-Level Operations");
			System.out.println("3. Exit the application");
			System.out.println("Enter your option in main menu");
			choice =sc.nextInt();
			switch(choice)
			{
			case 1:
				//create an object for displayfiles class
				// calling the display function.
				displayfiles obj=new displayfiles();
				obj.display();
				break;
			case 2:
				int opt;
		         do
				{
					System.out.println("1. Add the file to the existing directory list");
					System.out.println("2. Delete a user specified file from the existing directory list");
					System.out.println("3. Search a user specified file from the main directory");
					System.out.println("4. Navigate back to the main context");
					opt=sc.nextInt();
					switch(opt)
					{
					case 1:
						try { 
							//Create files in the root directory
							System.out.println("Enter the file name u want to add");
							//Take the input of file name from users.
							sc.nextLine();
							String fn= sc.nextLine();
							fn=fn+".txt";
							String d="D:\\";
							d=d+fn;
							 File myfile=new File(d);
							 if(myfile.createNewFile()) {
								 System.out.println("File created: "+fn);
							 }
							 else
							 {
								 System.out.println("File Already exists");
							 }
						}
							 catch(IOException e) {
								 System.out.println("An error occurred");
								 e.printStackTrace();
							 }
	
							 break; 
		
					case 2:
							//Deleting the files.
						System.out.println("Enter the file u want to delete");
						sc.nextLine();
						String fn= sc.nextLine();
						fn=fn+".txt";
						String d="D:\\";
						d=d+fn;
							File file=new File(d);
							if(file.delete()) {
								System.out.println(file+ " got deleted");
							}
								else
								{
									System.out.println("File not found");
								}
						break;
					case 3:
					{
						//Searching the files from the directory.
						System.out.println("Enter the file u want to search");
						sc.nextLine();
						String fnl= sc.nextLine();
						fnl=fnl+".txt";
						String di="D:\\";
						d=di+fnl;
						File myfile=new File(di);
						String[] flist= myfile.list();
						int flag=0;
						if(flist==null) {
							System.out.println("Empty directory");
						}
						else {
							for(int i=0;i<flist.length;i++) {
								String nidhi=flist[i];
								if(nidhi.equals(fnl)) {
									System.out.println(fnl + "\tfound");
									flag=1;
								}
							}
						}
						if (flag==0) {
							System.out.println("File not Found");
						}
					}
					break;
					case 4:
						//Navigating back to the main context.
						javaproject object=new javaproject();
						object.maincontent();
						break;
						default:
							System.out.println("Invalid choice");
							break;
					}
					}
						while(opt!=4);
							break;
			case 3:
				//Exit
				break;
			default:
					System.out.println("Invalid option");
			}
		}
		while(choice!=3);
		System.out.println("Thanks for using my application");
   }
}

					
				
