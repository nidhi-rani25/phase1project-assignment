package phase1project;

import java.io.File;

public class displayfiles {
	//Display the files in ascending order from the root directory.
	public void display()
	{
		File file=new File("D:\\");
		String[] files=file.list();
		for(String string :files)
			System.out.println(string);
	}


}
