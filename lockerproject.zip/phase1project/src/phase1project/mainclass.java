package phase1project;
public class mainclass {
	//Main function
   public static void main(String[] args) {
		javaproject object=new javaproject();
		object.maincontent();
		}
}
